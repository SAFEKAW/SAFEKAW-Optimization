suppressPackageStartupMessages({
  library(readr)
  library(dplyr)
  library(purrr)
  library(ggplot2)
  library(scales)
})

args <- commandArgs(trailingOnly = TRUE)
get_arg <- function(flag, default = NULL) {
  i <- match(flag, args)
  if (is.na(i) || i == length(args)) return(default)
  args[[i + 1]]
}

root <- normalizePath(get_arg("--root", "."), mustWork = TRUE)
outdir <- get_arg("--output", file.path(root, "local_optimization_analysis"))
dir.create(outdir, recursive = TRUE, showWarnings = FALSE)

pareto_files <- list.files(
  root,
  pattern = "^pareto_front_.*[.]csv$",
  recursive = TRUE,
  full.names = TRUE
)
if (!length(pareto_files)) stop("No Pareto-front CSV files found under: ", root)

read_front <- function(path) {
  x <- read_csv(path, show_col_types = FALSE)
  if (!"run_tag" %in% names(x)) {
    normalized <- gsub("\\\\", "/", path)
    x$run_tag <- sub(".*/outputs/runs/([^/]+)/.*", "\\1", normalized)
  }
  if (!"phase" %in% names(x)) x$phase <- "unconstrained"
  if (!"irrigation_technology_name" %in% names(x)) {
    x$irrigation_technology_name <- "current"
  }
  if (!"feasible" %in% names(x)) x$feasible <- TRUE
  x$source_file <- path
  x
}

solutions <- map_dfr(pareto_files, read_front) %>%
  filter(feasible) %>%
  filter(if_all(c(nitrate, irrigation, profit), is.finite))

required <- c(
  "run_tag", "scenario_name", "seed", "phase",
  "irrigation_technology_name", "nitrate", "irrigation", "profit"
)
missing <- setdiff(required, names(solutions))
if (length(missing)) stop("Pareto outputs missing: ", paste(missing, collapse = ", "))

inventory <- solutions %>%
  group_by(
    run_tag, phase, irrigation_technology_name, scenario_name, seed
  ) %>%
  summarise(
    solutions = n(),
    nitrate_min = min(nitrate),
    nitrate_max = max(nitrate),
    irrigation_min = min(irrigation),
    irrigation_max = max(irrigation),
    profit_min = min(profit),
    profit_max = max(profit),
    .groups = "drop"
  )
write_csv(inventory, file.path(outdir, "optimization_solution_inventory.csv"))

phase_summary <- solutions %>%
  group_by(run_tag, phase, irrigation_technology_name) %>%
  summarise(
    scenarios = n_distinct(scenario_name),
    seeds = n_distinct(seed),
    solutions = n(),
    nitrate_min = min(nitrate),
    nitrate_max = max(nitrate),
    irrigation_min = min(irrigation),
    irrigation_max = max(irrigation),
    profit_min = min(profit),
    profit_max = max(profit),
    .groups = "drop"
  )
write_csv(phase_summary, file.path(outdir, "optimization_summary_by_run.csv"))

plot_data <- solutions %>%
  mutate(
    nitrate_million_kg = nitrate / 1e6,
    irrigation_million_m3 = irrigation / 1e6,
    profit_million_usd = profit / 1e6,
    panel = paste(phase, irrigation_technology_name, sep = " | ")
  )

for (tag in unique(plot_data$run_tag)) {
  tag_data <- filter(plot_data, run_tag == tag)
  safe_tag <- gsub("[^A-Za-z0-9._-]", "_", tag)

  p <- ggplot(
    tag_data,
    aes(nitrate_million_kg, profit_million_usd, color = irrigation_million_m3)
  ) +
    geom_point(alpha = 0.55, size = 1.1) +
    facet_grid(panel ~ scenario_name, scales = "free") +
    scale_color_viridis_c(option = "C") +
    labs(
      title = paste("SAFE-KAW Pareto solutions:", tag),
      x = "Nitrate load (million kg/year)",
      y = "Net return (million USD/year)",
      color = "Irrigation\n(million m3/year)"
    ) +
    theme_minimal(base_size = 9) +
    theme(
      panel.grid.minor = element_blank(),
      axis.text.x = element_text(angle = 35, hjust = 1),
      legend.position = "bottom"
    )

  ggsave(
    file.path(outdir, paste0("pareto_", safe_tag, ".pdf")),
    p,
    width = max(14, 2.5 * n_distinct(tag_data$scenario_name)),
    height = max(6, 2.4 * n_distinct(tag_data$panel)),
    limitsize = FALSE
  )
}

benchmark_files <- list.files(
  root,
  pattern = "^optimization_benchmark_summary[.]csv$",
  recursive = TRUE,
  full.names = TRUE
)
if (length(benchmark_files)) {
  benchmark <- map_dfr(benchmark_files, read_csv, show_col_types = FALSE) %>%
    mutate(evaluations_proxy = popsize * generations)
  write_csv(benchmark, file.path(outdir, "benchmark_summary_combined.csv"))

  p_benchmark <- ggplot(
    benchmark,
    aes(evaluations_proxy, dominated_hypervolume)
  ) +
    geom_line() +
    geom_point(aes(size = elapsed_seconds), alpha = 0.8) +
    geom_text(
      aes(label = paste0("p", popsize, " g", generations)),
      nudge_y = 0.01,
      check_overlap = TRUE
    ) +
    scale_x_log10(labels = label_number()) +
    labs(
      title = "Optimizer-budget benchmark",
      x = "Population x generations (log scale)",
      y = "Normalized dominated hypervolume",
      size = "Runtime (seconds)"
    ) +
    theme_minimal(base_size = 11)
  ggsave(
    file.path(outdir, "optimizer_budget_benchmark.pdf"),
    p_benchmark, width = 8, height = 5.5
  )
}

cumulative_files <- list.files(
  root,
  pattern = "^cumulative_seed_stability[.]csv$",
  recursive = TRUE,
  full.names = TRUE
)
if (length(cumulative_files)) {
  cumulative <- map_dfr(cumulative_files, read_csv, show_col_types = FALSE)
  write_csv(cumulative, file.path(outdir, "cumulative_seed_stability_combined.csv"))

  p_stability <- ggplot(
    cumulative,
    aes(seeds_included, dominated_hypervolume)
  ) +
    geom_line() +
    geom_point() +
    facet_wrap(~scenario_name, scales = "free_y") +
    scale_x_continuous(breaks = sort(unique(cumulative$seeds_included))) +
    labs(
      title = "Cumulative Pareto-front stability across optimizer seeds",
      x = "Seeds pooled",
      y = "Normalized dominated hypervolume"
    ) +
    theme_minimal(base_size = 10)
  ggsave(
    file.path(outdir, "cumulative_seed_stability.pdf"),
    p_stability, width = 12, height = 8
  )
}

message("Read ", length(pareto_files), " Pareto files and ", nrow(solutions), " feasible solutions.")
message("Wrote local summaries and plots to: ", outdir)
